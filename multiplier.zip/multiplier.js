var multiplier = {
	sum: 1,
	multiply: function(value){
		return this.sum *= value;
	},
	getCurrentValue: function(value){
		return this.sum;
	}
}
